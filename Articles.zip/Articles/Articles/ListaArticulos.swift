//
//  ListaArticulos.swift
//  Lessons
//
//  Created by Alejandra Coeto on 08/10/24.
//

import Foundation

class ListaArticulos : ObservableObject {
    @Published var articulos = [Articulo]()
    
    
}
