//
//  PruebasUnitariasApp.swift
//  PruebasUnitarias
//
//  Created by Alejandra Coeto on 07/11/24.
//

import SwiftUI

@main
struct PruebasUnitariasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
